/*
Navicat MySQL Data Transfer

Source Server         : localhost_3306
Source Server Version : 50717
Source Host           : localhost:3306
Source Database       : cpn

Target Server Type    : MYSQL
Target Server Version : 50717
File Encoding         : 65001

Date: 2024-07-21 22:27:19
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for admin
-- ----------------------------
DROP TABLE IF EXISTS `admin`;
CREATE TABLE `admin` (
  `admin_id` int(11) NOT NULL AUTO_INCREMENT,
  `person_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`admin_id`),
  UNIQUE KEY `person_id` (`person_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of admin
-- ----------------------------
INSERT INTO `admin` VALUES ('1', '11');

-- ----------------------------
-- Table structure for competition
-- ----------------------------
DROP TABLE IF EXISTS `competition`;
CREATE TABLE `competition` (
  `comp_id` int(11) NOT NULL AUTO_INCREMENT,
  `comp_year` int(11) DEFAULT NULL,
  `comp_name` varchar(255) DEFAULT NULL,
  `comp_title` int(11) DEFAULT NULL,
  `poster_theme` varchar(255) DEFAULT NULL,
  `intro` varchar(255) DEFAULT NULL,
  `begin_date` varchar(255) DEFAULT NULL,
  `end_date` varchar(255) DEFAULT NULL,
  `max_team_size` int(11) DEFAULT NULL,
  `comp_over` int(11) DEFAULT NULL,
  PRIMARY KEY (`comp_id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of competition
-- ----------------------------
INSERT INTO `competition` VALUES ('1', '2021', '创新创业海报竞赛', '1', '创新创业海报竞赛', '一场创业者的盛宴', '2021-10-01', '2021-12-01', '3', '2');
INSERT INTO `competition` VALUES ('2', '2021', '科技发明海报竞赛', '1', '科技发明海报竞赛', '一次科技爱好者的狂欢', '2021-10-01', '2021-12-01', '3', '2');
INSERT INTO `competition` VALUES ('3', '2021', '艺术设计海报竞赛', '1', '艺术设计海报竞赛', '一场艺术创作者的聚会', '2021-10-01', '2021-12-01', '3', '2');
INSERT INTO `competition` VALUES ('4', '2021', '校园生活海报竞赛', '1', '校园生活海报竞赛', '一段青春的美好记录', '2021-10-01', '2021-12-01', '3', '2');
INSERT INTO `competition` VALUES ('5', '2021', '自然风光海报竞赛', '1', '自然风光海报竞赛', '领略大自然的神奇魅力', '2021-10-01', '2021-12-01', '3', '2');
INSERT INTO `competition` VALUES ('6', '2021', '城市风光海报竞赛', '1', '城市风光海报竞赛', '探索城市的独特风景', '2021-10-01', '2021-12-01', '3', '2');
INSERT INTO `competition` VALUES ('7', '2021', '动物世界海报竞赛', '1', '动物世界海报竞赛', '走进动物的奇妙天地', '2021-10-01', '2021-12-01', '3', '2');
INSERT INTO `competition` VALUES ('8', '2021', '植物世界海报竞赛', '1', '植物世界海报竞赛', '感受植物的生命之美', '2021-10-01', '2021-12-01', '3', '2');
INSERT INTO `competition` VALUES ('9', '2021', '历史文化海报竞赛', '1', '历史文化海报竞赛', '追溯历史的厚重足迹', '2021-10-01', '2021-12-01', '3', '2');
INSERT INTO `competition` VALUES ('10', '2021', '体育竞技海报竞赛', '1', '体育竞技海报竞赛', '挥洒运动的激情汗水', '2021-10-01', '2021-12-01', '3', '2');
INSERT INTO `competition` VALUES ('11', '2021', '音乐艺术海报竞赛', '1', '音乐艺术海报竞赛', '聆听音乐的动人旋律', '2021-10-01', '2021-12-01', '3', '2');
INSERT INTO `competition` VALUES ('12', '2021', '舞蹈艺术海报竞赛', '1', '舞蹈艺术海报竞赛', '展现舞蹈的优美姿态', '2021-10-01', '2021-12-01', '3', '2');
INSERT INTO `competition` VALUES ('13', '2021', '戏剧表演海报竞赛', '1', '戏剧表演海报竞赛', '演绎戏剧的精彩故事', '2021-10-01', '2021-12-01', '3', '2');
INSERT INTO `competition` VALUES ('14', '2021', '美食文化海报竞赛', '1', '美食文化海报竞赛', '品味美食的独特韵味', '2021-10-01', '2021-12-01', '3', '2');
INSERT INTO `competition` VALUES ('15', '2021', '时尚潮流海报竞赛', '1', '时尚潮流海报竞赛', '引领时尚的前沿风向', '2021-10-01', '2021-12-01', '3', '2');
INSERT INTO `competition` VALUES ('16', '2021', '建筑设计海报竞赛', '1', '建筑设计海报竞赛', '欣赏建筑的独特魅力', '2021-10-01', '2021-12-01', '3', '2');
INSERT INTO `competition` VALUES ('17', '2021', '工业设计海报竞赛', '1', '工业设计海报竞赛', '展现工业的创新力量', '2021-10-01', '2021-12-01', '3', '2');
INSERT INTO `competition` VALUES ('18', '2021', '航天科技海报竞赛', '1', '航天科技海报竞赛', '探索宇宙的无限奥秘', '2021-10-01', '2021-12-01', '3', '2');
INSERT INTO `competition` VALUES ('19', '2021', '海洋探索海报竞赛', '1', '海洋探索海报竞赛', '揭开海洋的神秘面纱', '2021-10-01', '2021-12-01', '3', '2');
INSERT INTO `competition` VALUES ('20', '2021', '传统文化海报竞赛', '1', '传统文化海报竞赛', '传承千年的文化瑰宝', '2021-10-01', '2021-12-01', '3', '2');
INSERT INTO `competition` VALUES ('21', '2021', '传统节气海报竞赛', '1', '传统节气海报竞赛', '感受节气的魅力世界', '2021-10-01', '2021-12-01', '3', '2');
INSERT INTO `competition` VALUES ('22', '2024', '梦幻幻想海报竞赛', '1', '梦幻幻想海报竞赛', '激发参赛者的想象力，创造出充满奇幻元素的海报', '2024-07-21 09:29:26', '2024-07-31 09:29:26', '3', '1');
INSERT INTO `competition` VALUES ('23', '2024', '未来城市海报竞赛', '1', '未来城市海报竞赛', '畅想未来城市的模样，展现科技与创新的融合', '2024-07-21 09:30:53', '2024-07-31 09:30:53', '3', '1');
INSERT INTO `competition` VALUES ('24', '2024', '童话世界海报竞赛', '1', '童话世界海报竞赛', '以经典或原创的童话故事为主题', '2024-07-21 09:32:18', '2024-07-31 09:32:18', '3', '1');
INSERT INTO `competition` VALUES ('25', '2024', '神秘宇宙海报竞赛', '1', '神秘宇宙海报竞赛', '探索宇宙的未知，描绘星辰、星系和太空冒险', '2024-07-21 09:32:57', '2024-07-31 09:32:57', '3', '1');
INSERT INTO `competition` VALUES ('26', '2024', '心灵之旅海报竞赛', '1', '心灵之旅海报竞赛', '表达内心的情感和思考，引发观众的共鸣', '2024-07-21 09:33:26', '2024-07-31 09:33:26', '3', '1');

-- ----------------------------
-- Table structure for comptitle
-- ----------------------------
DROP TABLE IF EXISTS `comptitle`;
CREATE TABLE `comptitle` (
  `cotle_id` int(11) NOT NULL AUTO_INCREMENT,
  `cotle_name` varchar(255) DEFAULT NULL,
  `comp_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`cotle_id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of comptitle
-- ----------------------------
INSERT INTO `comptitle` VALUES ('1', '生存创业', '1');
INSERT INTO `comptitle` VALUES ('2', '主动创业', '2');
INSERT INTO `comptitle` VALUES ('3', '创新创业', '3');
INSERT INTO `comptitle` VALUES ('4', '激情创业', '4');
INSERT INTO `comptitle` VALUES ('5', '智慧创业', '5');
INSERT INTO `comptitle` VALUES ('6', '勇敢创业', '6');
INSERT INTO `comptitle` VALUES ('7', '多元创业', '7');
INSERT INTO `comptitle` VALUES ('8', '绿色创业', '8');
INSERT INTO `comptitle` VALUES ('9', '科技创业', '9');
INSERT INTO `comptitle` VALUES ('10', '稳健创业', '10');
INSERT INTO `comptitle` VALUES ('11', '精准创业', '11');
INSERT INTO `comptitle` VALUES ('12', '特色创业', '12');
INSERT INTO `comptitle` VALUES ('13', '高效创业', '13');
INSERT INTO `comptitle` VALUES ('14', '融合创业', '14');
INSERT INTO `comptitle` VALUES ('15', '专业创业', '15');
INSERT INTO `comptitle` VALUES ('16', '活力创业', '16');
INSERT INTO `comptitle` VALUES ('17', '开拓创业', '17');
INSERT INTO `comptitle` VALUES ('18', '梦想创业', '18');
INSERT INTO `comptitle` VALUES ('19', '先锋创业', '19');
INSERT INTO `comptitle` VALUES ('20', '魅力创业', '20');
INSERT INTO `comptitle` VALUES ('21', '全国竞赛', '22');
INSERT INTO `comptitle` VALUES ('22', '中小学竞赛', '22');
INSERT INTO `comptitle` VALUES ('23', '大学生竞赛', '22');
INSERT INTO `comptitle` VALUES ('24', '全国竞赛', '23');
INSERT INTO `comptitle` VALUES ('25', '全国竞赛', '24');
INSERT INTO `comptitle` VALUES ('26', '全国竞赛', '25');
INSERT INTO `comptitle` VALUES ('27', '全国竞赛', '26');

-- ----------------------------
-- Table structure for comptye
-- ----------------------------
DROP TABLE IF EXISTS `comptye`;
CREATE TABLE `comptye` (
  `ctye_id` int(11) NOT NULL AUTO_INCREMENT,
  `ctye_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ctye_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of comptye
-- ----------------------------

-- ----------------------------
-- Table structure for entry
-- ----------------------------
DROP TABLE IF EXISTS `entry`;
CREATE TABLE `entry` (
  `entry_id` int(11) NOT NULL AUTO_INCREMENT,
  `entry_name` varchar(255) DEFAULT NULL,
  `entry_address` varchar(255) DEFAULT NULL,
  `comp_id` int(11) DEFAULT NULL,
  `cotle_id` int(11) DEFAULT NULL,
  `team_id` int(11) DEFAULT NULL,
  `score` double DEFAULT NULL,
  `like_num` int(11) DEFAULT NULL,
  `comp_over` int(11) DEFAULT NULL,
  `award_level` varchar(50) DEFAULT NULL,
  `cert_url` varchar(255) DEFAULT NULL,
  `entry_text` varchar(255) DEFAULT NULL,
  `team_end` int(11) DEFAULT NULL,
  PRIMARY KEY (`entry_id`)
) ENGINE=InnoDB AUTO_INCREMENT=53 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of entry
-- ----------------------------
INSERT INTO `entry` VALUES ('1', '生存创业宝典', '1.jfif ', '20', '20', '1', '100', '100', '2', '一等奖', 'assets/img/award.jpg', '优秀的数据分析工具，具有高度的实用性和创新性', '2');
INSERT INTO `entry` VALUES ('2', '海洋环保秘籍', '2.jfif ', '20', '20', '2', '99', '89', '2', '一等奖', 'assets/img/award.jpg', '优秀的数据分析工具，具有高度的实用性和创新性', '2');
INSERT INTO `entry` VALUES ('3', '创新科技指南', '3.jfif ', '20', '20', '3', '98', '88', '2', '一等奖', 'assets/img/award.jpg', '独特的科技成果，具有前瞻性和实用性', '2');
INSERT INTO `entry` VALUES ('4', '智慧发展方案', '4.jfif ', '20', '20', '4', '97', '87', '2', '二等奖', 'assets/img/award.jpg', '智慧引领的发展策略，极具创新性和可行性', '2');
INSERT INTO `entry` VALUES ('5', '激情拼搏计划', '5.jfif ', '20', '20', '5', '96', '86', '2', '二等奖', 'assets/img/award.jpg', '充满激情的拼搏方案，展现出强大的动力', '2');
INSERT INTO `entry` VALUES ('6', '多元融合案例', '6.jfif ', '20', '20', '6', '95', '85', '2', '二等奖', 'assets/img/award.jpg', '多元融合的成功案例，具有示范作用', '2');
INSERT INTO `entry` VALUES ('7', '绿色发展报告', '7.jfif ', '20', '20', '7', '94', '84', '2', '三等奖', 'assets/img/award.jpg', '全面的绿色发展报告，具有参考价值', '2');
INSERT INTO `entry` VALUES ('8', '科技引领成果', '8.jfif ', '20', '20', '8', '93', '83', '2', '三等奖', 'assets/img/award.jpg', '以科技引领的突出成果，具有引领性', '2');
INSERT INTO `entry` VALUES ('9', '稳健前行策略', '9.jfif ', '20', '20', '9', '92', '82', '2', '三等奖', 'assets/img/award.jpg', '稳健前行的有效策略，确保可持续发展', '2');
INSERT INTO `entry` VALUES ('10', '精准定位研究', '10.jfif ', '20', '20', '10', '91', '81', '2', '未获奖', '', '精准定位的深入研究，具有指导意义', '2');
INSERT INTO `entry` VALUES ('11', '特色创新作品', '11.jfif ', '20', '20', '11', '90', '80', '2', '未获奖', '', '独具特色的创新作品，展现独特魅力', '2');
INSERT INTO `entry` VALUES ('12', '高效行动方案', '12.jfif ', '20', '20', '12', '89', '79', '2', '未获奖', '', '高效行动的详细方案，具有可操作性', '2');
INSERT INTO `entry` VALUES ('13', '融合创新成果', '13.jfif ', '20', '20', '13', '88', '78', '2', '未获奖', '', '融合创新的显著成果，具有推广价值', '2');
INSERT INTO `entry` VALUES ('14', '专业专注报告', '14.jfif ', '20', '20', '14', '87', '77', '2', '未获奖', '', '专业专注的深入报告，具有权威性', '2');
INSERT INTO `entry` VALUES ('15', '梦想追逐作品', '15.jfif ', '20', '20', '15', '86', '76', '2', '未获奖', '', '勇敢追逐梦想的精彩作品，充满感染力', '2');
INSERT INTO `entry` VALUES ('16', '先锋探索研究', '16.jfif ', '20', '20', '16', '85', '75', '2', '未获奖', '', '先锋探索的前沿研究，具有开创性', '2');
INSERT INTO `entry` VALUES ('17', '魅力展现方案', '17.jfif ', '20', '20', '17', '84', '74', '2', '未获奖', '', '魅力展现的独特方案，具有吸引力', '2');
INSERT INTO `entry` VALUES ('18', '开拓创新计划', '18.jfif ', '20', '20', '18', '83', '73', '2', '未获奖', '', '开拓创新的宏伟计划，具有发展潜力', '2');
INSERT INTO `entry` VALUES ('19', '活力无限成果', '19.jfif ', '20', '20', '19', '82', '72', '2', '未获奖', '', '充满活力的创新成果，具有活力和竞争力', '2');
INSERT INTO `entry` VALUES ('20', '进取突破研究', '20.jfif ', '20', '20', '20', '81', '71', '2', '未获奖', '', '进取突破的深入研究，具有突破意义', '2');
INSERT INTO `entry` VALUES ('21', '飞跃发展方案', '21.jfif ', '20', '20', '21', '80', '70', '2', '未获奖', '', '实现飞跃发展的有效方案，具有战略意义', '2');
INSERT INTO `entry` VALUES ('22', '辉煌成就报告', '22.jfif ', '20', '20', '22', '79', '69', '2', '未获奖', '', '辉煌成就的详细报告，具有总结性', '2');
INSERT INTO `entry` VALUES ('23', '荣耀创新作品', '23.jfif ', '20', '20', '23', '78', '68', '2', '未获奖', '', '荣耀创新的杰出作品，具有代表性', '2');
INSERT INTO `entry` VALUES ('24', '卓越发展策略', '24.jfif ', '20', '20', '24', '77', '67', '2', '未获奖', '', '卓越发展的科学策略，具有指导性', '2');
INSERT INTO `entry` VALUES ('25', '非凡进取计划', '25.jfif ', '20', '20', '25', '76', '66', '2', '未获奖', '', '非凡进取的大胆计划，具有挑战性', '2');
INSERT INTO `entry` VALUES ('26', '领先探索成果', '26.jfif ', '20', '20', '26', '75', '65', '2', '未获奖', '', '领先探索的重要成果，具有领先性', '2');
INSERT INTO `entry` VALUES ('27', '创新引领案例', '27.jfif ', '20', '20', '27', '74', '64', '2', '未获奖', '', '创新引领的典型案例，具有引领作用', '2');
INSERT INTO `entry` VALUES ('28', '智慧突破方案', '28.jfif ', '20', '20', '28', '73', '63', '2', '未获奖', '', '智慧突破的有效方案，具有突破价值', '2');
INSERT INTO `entry` VALUES ('29', '激情引领作品', '29.jfif ', '20', '20', '29', '72', '62', '2', '未获奖', '', '激情引领的优秀作品，具有感染力', '2');
INSERT INTO `entry` VALUES ('30', '多元开拓研究', '30.jfif ', '20', '20', '30', '71', '61', '2', '未获奖', '', '多元开拓的深入研究，具有拓展性', '2');
INSERT INTO `entry` VALUES ('31', '烟花城堡', '1.jpg', '22', '22', '31', '50', '50', '1', '未结束', '未结束', '这幅海报的设计简洁明了，主题突出，色彩搭配和谐，视觉冲击力强，能够在第一时间吸引观众的注意力，有效地传达了核心信息', '1');
INSERT INTO `entry` VALUES ('32', '灵韵华章', '1-1.jpg', '22', '22', '32', '29', '30', '1', '未结束', '未结束', '这幅海报的设计简洁明了，主题突出，色彩搭配和谐，视觉冲击力强，能够在第一时间吸引观众的注意力，有效地传达了核心信息', '1');
INSERT INTO `entry` VALUES ('33', '幻彩艺境', '2.jpg', '22', '22', '33', '43.5', '89', '1', '未结束', '未结束', '这幅海报的设计简洁明了，主题突出，色彩搭配和谐，视觉冲击力强，能够在第一时间吸引观众的注意力，有效地传达了核心信息', '1');
INSERT INTO `entry` VALUES ('34', '臻美印象', '5.jpg', '22', '22', '34', '22.5', '34', '1', '未结束', '未结束', '这幅海报的设计简洁明了，主题突出，色彩搭配和谐，视觉冲击力强，能够在第一时间吸引观众的注意力，有效地传达了核心信息', '1');
INSERT INTO `entry` VALUES ('35', '雅逸风姿', '10.jpg', '22', '23', '35', '33.5', '125', '1', '未结束', '未结束', '这幅海报的设计简洁明了，主题突出，色彩搭配和谐，视觉冲击力强，能够在第一时间吸引观众的注意力，有效地传达了核心信息', '1');
INSERT INTO `entry` VALUES ('36', '绮梦幽情', '6.jpg', '22', '23', '36', '52', '70', '1', '未结束', '未结束', '这幅海报的设计简洁明了，主题突出，色彩搭配和谐，视觉冲击力强，能够在第一时间吸引观众的注意力，有效地传达了核心信息', '1');
INSERT INTO `entry` VALUES ('37', '萃华神韵', '23.jpg', '22', '22', '37', '38', '43', '1', '未结束', '未结束', '这幅海报的设计简洁明了，主题突出，色彩搭配和谐，视觉冲击力强，能够在第一时间吸引观众的注意力，有效地传达了核心信息', '1');
INSERT INTO `entry` VALUES ('38', '琼枝玉叶', '7.jpg', '22', '22', '38', '33.5', '93', '1', '未结束', '未结束', '这幅海报的设计简洁明了，主题突出，色彩搭配和谐，视觉冲击力强，能够在第一时间吸引观众的注意力，有效地传达了核心信息', '1');
INSERT INTO `entry` VALUES ('39', '逸品琳琅', '8.jpg', '22', '22', '40', '28', '48', '1', '未结束', '未结束', '这幅海报的设计简洁明了，主题突出，色彩搭配和谐，视觉冲击力强，能够在第一时间吸引观众的注意力，有效地传达了核心信息', '1');
INSERT INTO `entry` VALUES ('40', '馨逸风华', '4.jpg', '22', '22', '39', '45', '49', '1', '未结束', '未结束', '这幅海报的设计简洁明了，主题突出，色彩搭配和谐，视觉冲击力强，能够在第一时间吸引观众的注意力，有效地传达了核心信息', '1');
INSERT INTO `entry` VALUES ('41', '花与月', '20.jpg', '23', '24', '41', '33', '43', '1', '未结束', '未结束', '这幅海报的设计简洁明了，主题突出，色彩搭配和谐，视觉冲击力强，能够在第一时间吸引观众的注意力，有效地传达了核心信息', '1');
INSERT INTO `entry` VALUES ('42', '遇见春天', '21.jpg', '23', '24', '42', '34', '55', '1', '未结束', '未结束', '这幅海报的设计简洁明了，主题突出，色彩搭配和谐，视觉冲击力强，能够在第一时间吸引观众的注意力，有效地传达了核心信息', '1');
INSERT INTO `entry` VALUES ('43', '花与月2', '22.jpg', '23', '24', '43', '34.5', '23', '1', '未结束', '未结束', '这幅海报的设计简洁明了，主题突出，色彩搭配和谐，视觉冲击力强，能够在第一时间吸引观众的注意力，有效地传达了核心信息', '1');
INSERT INTO `entry` VALUES ('44', '狗狗与春天', '24.jpg', '24', '25', '44', '44.5', '64', '1', '未结束', '未结束', '这幅海报的设计简洁明了，主题突出，色彩搭配和谐，视觉冲击力强，能够在第一时间吸引观众的注意力，有效地传达了核心信息', '1');
INSERT INTO `entry` VALUES ('45', '猫与湖', '25.jpg', '24', '25', '45', '44.5', '73', '1', '未结束', '未结束', '这幅海报的设计简洁明了，主题突出，色彩搭配和谐，视觉冲击力强，能够在第一时间吸引观众的注意力，有效地传达了核心信息', '1');
INSERT INTO `entry` VALUES ('46', '月', '9.jpg', '23', '24', '46', '44', '67', '1', '未结束', '未结束', '这幅海报的设计简洁明了，主题突出，色彩搭配和谐，视觉冲击力强，能够在第一时间吸引观众的注意力，有效地传达了核心信息', '1');
INSERT INTO `entry` VALUES ('47', '椰子树', '26.jpg', '25', '26', '47', '44.5', '66', '1', '未结束', '未结束', '这幅海报的设计简洁明了，主题突出，色彩搭配和谐，视觉冲击力强，能够在第一时间吸引观众的注意力，有效地传达了核心信息', '1');
INSERT INTO `entry` VALUES ('48', '落日于海', '27.jpg', '25', '26', '48', '44.5', '54', '1', '未结束', '未结束', '这幅海报的设计简洁明了，主题突出，色彩搭配和谐，视觉冲击力强，能够在第一时间吸引观众的注意力，有效地传达了核心信息', '1');
INSERT INTO `entry` VALUES ('49', '春日', '28.jpg', '25', '26', '49', '44.5', '64', '1', '未结束', '未结束', '这幅海报的设计简洁明了，主题突出，色彩搭配和谐，视觉冲击力强，能够在第一时间吸引观众的注意力，有效地传达了核心信息', '1');
INSERT INTO `entry` VALUES ('50', '星空', '3.jpg', '26', '27', '50', '44.5', '65', '1', '未结束', '未结束', '这幅海报的设计简洁明了，主题突出，色彩搭配和谐，视觉冲击力强，能够在第一时间吸引观众的注意力，有效地传达了核心信息', '1');
INSERT INTO `entry` VALUES ('51', '宣传海报', '1-2.jpg', '26', '27', '51', '44.5', '66', '1', '未结束', '未结束', '这幅海报的设计简洁明了，主题突出，色彩搭配和谐，视觉冲击力强，能够在第一时间吸引观众的注意力，有效地传达了核心信息', '1');
INSERT INTO `entry` VALUES ('52', '春暖花开', '11.jpg', '26', '27', '52', '38.5', '88', '1', '未结束', '未结束', '这幅海报的设计简洁明了，主题突出，色彩搭配和谐，视觉冲击力强，能够在第一时间吸引观众的注意力，有效地传达了核心信息', '1');

-- ----------------------------
-- Table structure for history
-- ----------------------------
DROP TABLE IF EXISTS `history`;
CREATE TABLE `history` (
  `his_id` int(11) NOT NULL AUTO_INCREMENT,
  `person_id` int(11) DEFAULT NULL,
  `team_id` int(11) DEFAULT NULL,
  `award_level` varchar(50) DEFAULT NULL,
  `cert_url` varchar(255) DEFAULT NULL,
  `comp_id` int(11) DEFAULT NULL,
  `cotle_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`his_id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of history
-- ----------------------------
INSERT INTO `history` VALUES ('1', '12', '1', '传统节气海报竞赛 一等奖', 'assets/img/award.jpg', '20', '20');
INSERT INTO `history` VALUES ('2', '13', '2', '传统节气海报竞赛 一等奖', 'assets/img/award.jpg', '20', '20');
INSERT INTO `history` VALUES ('3', '14', '3', '传统节气海报竞赛 一等奖', 'assets/img/award.jpg', '20', '20');
INSERT INTO `history` VALUES ('4', '15', '4', '传统节气海报竞赛 二等奖', 'assets/img/award.jpg', '20', '20');
INSERT INTO `history` VALUES ('5', '16', '5', '传统节气海报竞赛 二等奖', 'assets/img/award.jpg', '20', '20');
INSERT INTO `history` VALUES ('6', '17', '6', '传统节气海报竞赛 二等奖', 'assets/img/award.jpg', '20', '20');
INSERT INTO `history` VALUES ('7', '18', '7', '传统节气海报竞赛 三等奖', 'assets/img/award.jpg', '20', '20');
INSERT INTO `history` VALUES ('8', '19', '8', '传统节气海报竞赛 三等奖', 'assets/img/award.jpg', '20', '20');
INSERT INTO `history` VALUES ('9', '20', '9', '传统节气海报竞赛 三等奖', 'assets/img/award.jpg', '20', '20');
INSERT INTO `history` VALUES ('10', '42', '1', '传统节气海报竞赛 一等奖', 'assets/img/award.jpg', '20', '20');
INSERT INTO `history` VALUES ('11', '43', '1', '传统节气海报竞赛 一等奖', 'assets/img/award.jpg', '20', '20');
INSERT INTO `history` VALUES ('12', '44', '2', '传统节气海报竞赛 一等奖', 'assets/img/award.jpg', '20', '20');
INSERT INTO `history` VALUES ('13', '45', '2', '传统节气海报竞赛 一等奖', 'assets/img/award.jpg', '20', '20');
INSERT INTO `history` VALUES ('14', '46', '3', '传统节气海报竞赛 一等奖', 'assets/img/award.jpg', '20', '20');
INSERT INTO `history` VALUES ('15', '47', '3', '传统节气海报竞赛 一等奖', 'assets/img/award.jpg', '20', '20');
INSERT INTO `history` VALUES ('16', '48', '4', '传统节气海报竞赛 一等奖', 'assets/img/award.jpg', '20', '20');
INSERT INTO `history` VALUES ('17', '49', '4', '传统节气海报竞赛 一等奖', 'assets/img/award.jpg', '20', '20');
INSERT INTO `history` VALUES ('18', '50', '5', '传统节气海报竞赛 一等奖', 'assets/img/award.jpg', '20', '20');
INSERT INTO `history` VALUES ('19', '51', '5', '传统节气海报竞赛 一等奖', 'assets/img/award.jpg', '20', '20');
INSERT INTO `history` VALUES ('20', '52', '6', '传统节气海报竞赛 一等奖', 'assets/img/award.jpg', '20', '20');
INSERT INTO `history` VALUES ('21', '53', '6', '传统节气海报竞赛 一等奖', 'assets/img/award.jpg', '20', '20');
INSERT INTO `history` VALUES ('22', '54', '7', '传统节气海报竞赛 一等奖', 'assets/img/award.jpg', '20', '20');
INSERT INTO `history` VALUES ('23', '55', '7', '传统节气海报竞赛 一等奖', 'assets/img/award.jpg', '20', '20');
INSERT INTO `history` VALUES ('24', '56', '8', '传统节气海报竞赛 一等奖', 'assets/img/award.jpg', '20', '20');
INSERT INTO `history` VALUES ('25', '57', '8', '传统节气海报竞赛 一等奖', 'assets/img/award.jpg', '20', '20');
INSERT INTO `history` VALUES ('26', '58', '9', '传统节气海报竞赛 一等奖', 'assets/img/award.jpg', '20', '20');
INSERT INTO `history` VALUES ('27', '59', '9', '传统节气海报竞赛 一等奖', 'assets/img/award.jpg', '20', '20');

-- ----------------------------
-- Table structure for judge
-- ----------------------------
DROP TABLE IF EXISTS `judge`;
CREATE TABLE `judge` (
  `judge_id` int(11) NOT NULL AUTO_INCREMENT,
  `person_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`judge_id`),
  UNIQUE KEY `person_id` (`person_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of judge
-- ----------------------------
INSERT INTO `judge` VALUES ('1', '1');
INSERT INTO `judge` VALUES ('2', '2');
INSERT INTO `judge` VALUES ('3', '3');
INSERT INTO `judge` VALUES ('4', '4');
INSERT INTO `judge` VALUES ('5', '5');
INSERT INTO `judge` VALUES ('6', '6');
INSERT INTO `judge` VALUES ('7', '7');
INSERT INTO `judge` VALUES ('8', '8');
INSERT INTO `judge` VALUES ('9', '9');
INSERT INTO `judge` VALUES ('10', '10');

-- ----------------------------
-- Table structure for news
-- ----------------------------
DROP TABLE IF EXISTS `news`;
CREATE TABLE `news` (
  `news_id` int(11) NOT NULL AUTO_INCREMENT,
  `news_type` int(11) DEFAULT NULL,
  `target_id` int(11) DEFAULT NULL,
  `news_content` varchar(255) DEFAULT NULL,
  `news_processed` int(11) DEFAULT NULL,
  `news_time` varchar(255) DEFAULT NULL,
  `team_id` int(11) DEFAULT NULL,
  `sender_id` int(11) DEFAULT '0',
  PRIMARY KEY (`news_id`)
) ENGINE=InnoDB AUTO_INCREMENT=48 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of news
-- ----------------------------
INSERT INTO `news` VALUES ('1', '1', '22', 'name11同学你好，我是name1，现邀请你成为队伍的一员一同参加梦幻幻想海报竞赛', '1', '2024-07-21 09:37:05', '31', '12');
INSERT INTO `news` VALUES ('2', '1', '23', 'name12同学你好，我是name1，现邀请你成为队伍的一员一同参加梦幻幻想海报竞赛', '1', '2024-07-21 09:37:06', '31', '12');
INSERT INTO `news` VALUES ('3', '1', '24', 'name13同学你好，我是name2，现邀请你成为队伍的一员一同参加梦幻幻想海报竞赛', '1', '2024-07-21 09:39:44', '32', '13');
INSERT INTO `news` VALUES ('4', '1', '25', 'name14同学你好，我是name2，现邀请你成为队伍的一员一同参加梦幻幻想海报竞赛', '1', '2024-07-21 09:39:45', '32', '13');
INSERT INTO `news` VALUES ('5', '1', '26', 'name15同学你好，我是name3，现邀请你成为队伍的一员一同参加梦幻幻想海报竞赛', '1', '2024-07-21 09:41:10', '33', '14');
INSERT INTO `news` VALUES ('6', '1', '27', 'name16同学你好，我是name3，现邀请你成为队伍的一员一同参加梦幻幻想海报竞赛', '1', '2024-07-21 09:41:11', '33', '14');
INSERT INTO `news` VALUES ('7', '1', '28', 'name17同学你好，我是name4，现邀请你成为队伍的一员一同参加梦幻幻想海报竞赛', '1', '2024-07-21 09:41:57', '34', '15');
INSERT INTO `news` VALUES ('8', '1', '29', 'name18同学你好，我是name4，现邀请你成为队伍的一员一同参加梦幻幻想海报竞赛', '1', '2024-07-21 09:41:57', '34', '15');
INSERT INTO `news` VALUES ('9', '1', '30', 'name19同学你好，我是name5，现邀请你成为队伍的一员一同参加梦幻幻想海报竞赛', '1', '2024-07-21 09:42:35', '35', '16');
INSERT INTO `news` VALUES ('10', '1', '31', 'name20同学你好，我是name5，现邀请你成为队伍的一员一同参加梦幻幻想海报竞赛', '1', '2024-07-21 09:42:36', '35', '16');
INSERT INTO `news` VALUES ('11', '1', '32', 'name21同学你好，我是name6，现邀请你成为队伍的一员一同参加梦幻幻想海报竞赛', '1', '2024-07-21 09:43:13', '36', '17');
INSERT INTO `news` VALUES ('12', '1', '33', 'name22同学你好，我是name6，现邀请你成为队伍的一员一同参加梦幻幻想海报竞赛', '1', '2024-07-21 09:43:14', '36', '17');
INSERT INTO `news` VALUES ('13', '1', '34', 'name23同学你好，我是name7，现邀请你成为队伍的一员一同参加梦幻幻想海报竞赛', '1', '2024-07-21 09:43:51', '37', '18');
INSERT INTO `news` VALUES ('14', '1', '35', 'name24同学你好，我是name7，现邀请你成为队伍的一员一同参加梦幻幻想海报竞赛', '1', '2024-07-21 09:43:51', '37', '18');
INSERT INTO `news` VALUES ('15', '1', '36', 'name25同学你好，我是name8，现邀请你成为队伍的一员一同参加梦幻幻想海报竞赛', '1', '2024-07-21 09:44:35', '38', '19');
INSERT INTO `news` VALUES ('16', '1', '37', 'name26同学你好，我是name8，现邀请你成为队伍的一员一同参加梦幻幻想海报竞赛', '1', '2024-07-21 09:44:35', '38', '19');
INSERT INTO `news` VALUES ('17', '1', '39', 'name28同学你好，我是name9，现邀请你成为队伍的一员一同参加梦幻幻想海报竞赛', '1', '2024-07-21 09:46:03', '39', '20');
INSERT INTO `news` VALUES ('18', '1', '40', 'name29同学你好，我是name9，现邀请你成为队伍的一员一同参加梦幻幻想海报竞赛', '1', '2024-07-21 09:46:03', '39', '20');
INSERT INTO `news` VALUES ('19', '1', '41', 'name30同学你好，我是name10，现邀请你成为队伍的一员一同参加梦幻幻想海报竞赛', '1', '2024-07-21 09:46:40', '40', '21');
INSERT INTO `news` VALUES ('20', '1', '42', 'name31同学你好，我是name10，现邀请你成为队伍的一员一同参加梦幻幻想海报竞赛', '1', '2024-07-21 09:46:41', '40', '21');
INSERT INTO `news` VALUES ('21', '1', '38', 'name27同学你好，我是name40，现邀请你成为队伍的一员一同参加未来城市海报竞赛', '1', '2024-07-21 10:25:17', '41', '51');
INSERT INTO `news` VALUES ('22', '1', '43', 'name32同学你好，我是name40，现邀请你成为队伍的一员一同参加未来城市海报竞赛', '1', '2024-07-21 10:25:17', '41', '51');
INSERT INTO `news` VALUES ('23', '1', '44', 'name33同学你好，我是name41，现邀请你成为队伍的一员一同参加未来城市海报竞赛', '1', '2024-07-21 10:26:42', '42', '52');
INSERT INTO `news` VALUES ('24', '1', '45', 'name34同学你好，我是name41，现邀请你成为队伍的一员一同参加未来城市海报竞赛', '1', '2024-07-21 10:26:43', '42', '52');
INSERT INTO `news` VALUES ('25', '1', '46', 'name35同学你好，我是name42，现邀请你成为队伍的一员一同参加未来城市海报竞赛', '1', '2024-07-21 10:27:21', '43', '53');
INSERT INTO `news` VALUES ('26', '1', '47', 'name36同学你好，我是name42，现邀请你成为队伍的一员一同参加未来城市海报竞赛', '1', '2024-07-21 10:27:22', '43', '53');
INSERT INTO `news` VALUES ('27', '1', '48', 'name37同学你好，我是name43，现邀请你成为队伍的一员一同参加童话世界海报竞赛', '1', '2024-07-21 10:29:22', '44', '54');
INSERT INTO `news` VALUES ('28', '1', '49', 'name38同学你好，我是name43，现邀请你成为队伍的一员一同参加童话世界海报竞赛', '1', '2024-07-21 10:29:23', '44', '54');
INSERT INTO `news` VALUES ('29', '1', '50', 'name39同学你好，我是name44，现邀请你成为队伍的一员一同参加童话世界海报竞赛', '1', '2024-07-21 10:29:54', '45', '55');
INSERT INTO `news` VALUES ('30', '1', '71', 'name60同学你好，我是name44，现邀请你成为队伍的一员一同参加童话世界海报竞赛', '1', '2024-07-21 10:30:01', '45', '55');
INSERT INTO `news` VALUES ('31', '1', '72', 'name61同学你好，我是name45，现邀请你成为队伍的一员一同参加未来城市海报竞赛', '1', '2024-07-21 10:30:25', '46', '56');
INSERT INTO `news` VALUES ('32', '1', '73', 'name62同学你好，我是name45，现邀请你成为队伍的一员一同参加未来城市海报竞赛', '1', '2024-07-21 10:30:26', '46', '56');
INSERT INTO `news` VALUES ('33', '1', '74', 'name63同学你好，我是name46，现邀请你成为队伍的一员一同参加神秘宇宙海报竞赛', '1', '2024-07-21 10:35:38', '47', '57');
INSERT INTO `news` VALUES ('34', '1', '75', 'name64同学你好，我是name46，现邀请你成为队伍的一员一同参加神秘宇宙海报竞赛', '1', '2024-07-21 10:35:39', '47', '57');
INSERT INTO `news` VALUES ('35', '1', '76', 'name65同学你好，我是name47，现邀请你成为队伍的一员一同参加神秘宇宙海报竞赛', '1', '2024-07-21 10:36:29', '48', '58');
INSERT INTO `news` VALUES ('36', '1', '77', 'name66同学你好，我是name47，现邀请你成为队伍的一员一同参加神秘宇宙海报竞赛', '1', '2024-07-21 10:36:30', '48', '58');
INSERT INTO `news` VALUES ('37', '1', '78', 'name67同学你好，我是name48，现邀请你成为队伍的一员一同参加神秘宇宙海报竞赛', '1', '2024-07-21 10:37:20', '49', '59');
INSERT INTO `news` VALUES ('38', '1', '79', 'name68同学你好，我是name48，现邀请你成为队伍的一员一同参加神秘宇宙海报竞赛', '1', '2024-07-21 10:37:21', '49', '59');
INSERT INTO `news` VALUES ('39', '1', '80', 'name69同学你好，我是name49，现邀请你成为队伍的一员一同参加心灵之旅海报竞赛', '1', '2024-07-21 10:37:56', '50', '60');
INSERT INTO `news` VALUES ('40', '1', '81', 'name70同学你好，我是name49，现邀请你成为队伍的一员一同参加心灵之旅海报竞赛', '1', '2024-07-21 10:37:57', '50', '60');
INSERT INTO `news` VALUES ('41', '1', '82', 'name71同学你好，我是name50，现邀请你成为队伍的一员一同参加心灵之旅海报竞赛', '1', '2024-07-21 10:38:38', '51', '61');
INSERT INTO `news` VALUES ('42', '1', '83', 'name72同学你好，我是name50，现邀请你成为队伍的一员一同参加心灵之旅海报竞赛', '1', '2024-07-21 10:38:39', '51', '61');
INSERT INTO `news` VALUES ('43', '1', '84', 'name73同学你好，我是name51，现邀请你成为队伍的一员一同参加心灵之旅海报竞赛', '1', '2024-07-21 10:39:19', '52', '62');
INSERT INTO `news` VALUES ('44', '1', '85', 'name74同学你好，我是name51，现邀请你成为队伍的一员一同参加心灵之旅海报竞赛', '1', '2024-07-21 10:39:20', '52', '62');
INSERT INTO `news` VALUES ('45', '0', '0', '心灵之旅海报大赛即将开始，欢迎全国海报爱好者参加。', '1', '2024-07-12 10:00:01', '0', '0');
INSERT INTO `news` VALUES ('46', '0', '0', '梦幻幻想海报大赛即将开始，欢迎全国海报爱好者参加。', '1', '2024-07-09 10:30:02', '0', '0');
INSERT INTO `news` VALUES ('47', '0', '0', '未来城市海报大赛即将开始，欢迎全国海报爱好者参加。', '1', '2024-07-03 13:30:03', '0', '0');

-- ----------------------------
-- Table structure for person
-- ----------------------------
DROP TABLE IF EXISTS `person`;
CREATE TABLE `person` (
  `person_id` int(11) NOT NULL AUTO_INCREMENT,
  `person_type` int(11) DEFAULT NULL,
  `person_captain` int(11) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`person_id`)
) ENGINE=InnoDB AUTO_INCREMENT=172 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of person
-- ----------------------------
INSERT INTO `person` VALUES ('1', '3', '1', 'judgeA', 'judgeA', '123456', 'judgeA@example.com', '12345678901');
INSERT INTO `person` VALUES ('2', '3', '1', 'judgeB', 'judgeB', '123456', 'judgeB@example.com', '12345678902');
INSERT INTO `person` VALUES ('3', '3', '1', 'judgeC', 'judgeC', '123456', 'judgeC@example.com', '12345678903');
INSERT INTO `person` VALUES ('4', '3', '1', 'judgeD', 'judgeD', '123456', 'judgeD@example.com', '12345678904');
INSERT INTO `person` VALUES ('5', '3', '1', 'judgeE', 'judgeE', '123456', 'judgeE@example.com', '12345678905');
INSERT INTO `person` VALUES ('6', '3', '1', 'judgeF', 'judgeF', '123456', 'judgeF@example.com', '12345678906');
INSERT INTO `person` VALUES ('7', '3', '1', 'judgeG', 'judgeG', '123456', 'judgeG@example.com', '12345678907');
INSERT INTO `person` VALUES ('8', '3', '1', 'judgeH', 'judgeH', '123456', 'judgeH@example.com', '12345678908');
INSERT INTO `person` VALUES ('9', '3', '1', 'judgeI', 'judgeI', '123456', 'judgeI@example.com', '12345678909');
INSERT INTO `person` VALUES ('10', '3', '1', 'judgeJ', 'judgeJ', '123456', 'judgeJ@example.com', '12345678910');
INSERT INTO `person` VALUES ('11', '4', '1', 'adminA', 'adminA', '123456', 'adminA@example.com', '12345678901');
INSERT INTO `person` VALUES ('12', '2', '2', 'name1', 'user1', '123456', 'user1@example.com', '12345678901');
INSERT INTO `person` VALUES ('13', '2', '2', 'name2', 'user2', '123456', 'user2@example.com', '12345678902');
INSERT INTO `person` VALUES ('14', '2', '2', 'name3', 'user3', '123456', 'user3@example.com', '12345678903');
INSERT INTO `person` VALUES ('15', '2', '2', 'name4', 'user4', '123456', 'user4@example.com', '12345678904');
INSERT INTO `person` VALUES ('16', '2', '2', 'name5', 'user5', '123456', 'user5@example.com', '12345678905');
INSERT INTO `person` VALUES ('17', '2', '2', 'name6', 'user6', '123456', 'user6@example.com', '12345678906');
INSERT INTO `person` VALUES ('18', '2', '2', 'name7', 'user7', '123456', 'user7@example.com', '12345678907');
INSERT INTO `person` VALUES ('19', '2', '2', 'name8', 'user8', '123456', 'user8@example.com', '12345678908');
INSERT INTO `person` VALUES ('20', '2', '2', 'name9', 'user9', '123456', 'user9@example.com', '12345678909');
INSERT INTO `person` VALUES ('21', '2', '2', 'name10', 'user10', '123456', 'user10@example.com', '12345678910');
INSERT INTO `person` VALUES ('22', '2', '1', 'name11', 'user11', '123456', 'user11@example.com', '12345678911');
INSERT INTO `person` VALUES ('23', '2', '1', 'name12', 'user12', '123456', 'user12@example.com', '12345678912');
INSERT INTO `person` VALUES ('24', '2', '1', 'name13', 'user13', '123456', 'user13@example.com', '12345678913');
INSERT INTO `person` VALUES ('25', '2', '1', 'name14', 'user14', '123456', 'user14@example.com', '12345678914');
INSERT INTO `person` VALUES ('26', '2', '1', 'name15', 'user15', '123456', 'user15@example.com', '12345678915');
INSERT INTO `person` VALUES ('27', '2', '1', 'name16', 'user16', '123456', 'user16@example.com', '12345678916');
INSERT INTO `person` VALUES ('28', '2', '1', 'name17', 'user17', '123456', 'user17@example.com', '12345678917');
INSERT INTO `person` VALUES ('29', '2', '1', 'name18', 'user18', '123456', 'user18@example.com', '12345678918');
INSERT INTO `person` VALUES ('30', '2', '1', 'name19', 'user19', '123456', 'user19@example.com', '12345678919');
INSERT INTO `person` VALUES ('31', '2', '1', 'name20', 'user20', '123456', 'user20@example.com', '12345678920');
INSERT INTO `person` VALUES ('32', '2', '1', 'name21', 'user21', '123456', 'user21@example.com', '12345678921');
INSERT INTO `person` VALUES ('33', '2', '1', 'name22', 'user22', '123456', 'user22@example.com', '12345678922');
INSERT INTO `person` VALUES ('34', '2', '1', 'name23', 'user23', '123456', 'user23@example.com', '12345678923');
INSERT INTO `person` VALUES ('35', '2', '1', 'name24', 'user24', '123456', 'user24@example.com', '12345678924');
INSERT INTO `person` VALUES ('36', '2', '1', 'name25', 'user25', '123456', 'user25@example.com', '12345678925');
INSERT INTO `person` VALUES ('37', '2', '1', 'name26', 'user26', '123456', 'user26@example.com', '12345678926');
INSERT INTO `person` VALUES ('38', '2', '1', 'name27', 'user27', '123456', 'user27@example.com', '12345678927');
INSERT INTO `person` VALUES ('39', '2', '1', 'name28', 'user28', '123456', 'user28@example.com', '12345678928');
INSERT INTO `person` VALUES ('40', '2', '1', 'name29', 'user29', '123456', 'user29@example.com', '12345678929');
INSERT INTO `person` VALUES ('41', '2', '1', 'name30', 'user30', '123456', 'user30@example.com', '12345678930');
INSERT INTO `person` VALUES ('42', '2', '1', 'name31', 'user31', '123456', 'user31@example.com', '12345678931');
INSERT INTO `person` VALUES ('43', '2', '1', 'name32', 'user32', '123456', 'user32@example.com', '12345678932');
INSERT INTO `person` VALUES ('44', '2', '1', 'name33', 'user33', '123456', 'user33@example.com', '12345678933');
INSERT INTO `person` VALUES ('45', '2', '1', 'name34', 'user34', '123456', 'user34@example.com', '12345678934');
INSERT INTO `person` VALUES ('46', '2', '1', 'name35', 'user35', '123456', 'user35@example.com', '12345678935');
INSERT INTO `person` VALUES ('47', '2', '1', 'name36', 'user36', '123456', 'user36@example.com', '12345678936');
INSERT INTO `person` VALUES ('48', '2', '1', 'name37', 'user37', '123456', 'user37@example.com', '12345678937');
INSERT INTO `person` VALUES ('49', '2', '1', 'name38', 'user38', '123456', 'user38@example.com', '12345678938');
INSERT INTO `person` VALUES ('50', '2', '1', 'name39', 'user39', '123456', 'user39@example.com', '12345678939');
INSERT INTO `person` VALUES ('51', '2', '2', 'name40', 'user40', '123456', 'user40@example.com', '12345678940');
INSERT INTO `person` VALUES ('52', '2', '2', 'name41', 'user41', '123456', 'user41@example.com', '12345678941');
INSERT INTO `person` VALUES ('53', '2', '2', 'name42', 'user42', '123456', 'user42@example.com', '12345678942');
INSERT INTO `person` VALUES ('54', '2', '2', 'name43', 'user43', '123456', 'user43@example.com', '12345678943');
INSERT INTO `person` VALUES ('55', '2', '2', 'name44', 'user44', '123456', 'user44@example.com', '12345678944');
INSERT INTO `person` VALUES ('56', '2', '2', 'name45', 'user45', '123456', 'user45@example.com', '12345678945');
INSERT INTO `person` VALUES ('57', '2', '2', 'name46', 'user46', '123456', 'user46@example.com', '12345678946');
INSERT INTO `person` VALUES ('58', '2', '2', 'name47', 'user47', '123456', 'user47@example.com', '12345678947');
INSERT INTO `person` VALUES ('59', '2', '2', 'name48', 'user48', '123456', 'user48@example.com', '12345678948');
INSERT INTO `person` VALUES ('60', '2', '2', 'name49', 'user49', '123456', 'user49@example.com', '12345678949');
INSERT INTO `person` VALUES ('61', '2', '2', 'name50', 'user50', '123456', 'user50@example.com', '12345678950');
INSERT INTO `person` VALUES ('62', '2', '2', 'name51', 'user51', '123456', 'user51@example.com', '12345678951');
INSERT INTO `person` VALUES ('63', '1', '1', 'name52', 'user52', '123456', 'user52@example.com', '12345678952');
INSERT INTO `person` VALUES ('64', '1', '1', 'name53', 'user53', '123456', 'user53@example.com', '12345678953');
INSERT INTO `person` VALUES ('65', '1', '1', 'name54', 'user54', '123456', 'user54@example.com', '12345678954');
INSERT INTO `person` VALUES ('66', '1', '1', 'name55', 'user55', '123456', 'user55@example.com', '12345678955');
INSERT INTO `person` VALUES ('67', '1', '1', 'name56', 'user56', '123456', 'user56@example.com', '12345678956');
INSERT INTO `person` VALUES ('68', '1', '1', 'name57', 'user57', '123456', 'user57@example.com', '12345678957');
INSERT INTO `person` VALUES ('69', '1', '1', 'name58', 'user58', '123456', 'user58@example.com', '12345678958');
INSERT INTO `person` VALUES ('70', '1', '1', 'name59', 'user59', '123456', 'user59@example.com', '12345678959');
INSERT INTO `person` VALUES ('71', '2', '1', 'name60', 'user60', '123456', 'user60@example.com', '12345678960');
INSERT INTO `person` VALUES ('72', '2', '1', 'name61', 'user61', '123456', 'user61@example.com', '12345678961');
INSERT INTO `person` VALUES ('73', '2', '1', 'name62', 'user62', '123456', 'user62@example.com', '12345678962');
INSERT INTO `person` VALUES ('74', '2', '1', 'name63', 'user63', '123456', 'user63@example.com', '12345678963');
INSERT INTO `person` VALUES ('75', '2', '1', 'name64', 'user64', '123456', 'user64@example.com', '12345678964');
INSERT INTO `person` VALUES ('76', '2', '1', 'name65', 'user65', '123456', 'user65@example.com', '12345678965');
INSERT INTO `person` VALUES ('77', '2', '1', 'name66', 'user66', '123456', 'user66@example.com', '12345678966');
INSERT INTO `person` VALUES ('78', '2', '1', 'name67', 'user67', '123456', 'user67@example.com', '12345678967');
INSERT INTO `person` VALUES ('79', '2', '1', 'name68', 'user68', '123456', 'user68@example.com', '12345678968');
INSERT INTO `person` VALUES ('80', '2', '1', 'name69', 'user69', '123456', 'user69@example.com', '12345678969');
INSERT INTO `person` VALUES ('81', '2', '1', 'name70', 'user70', '123456', 'user70@example.com', '12345678970');
INSERT INTO `person` VALUES ('82', '2', '1', 'name71', 'user71', '123456', 'user71@example.com', '12345678971');
INSERT INTO `person` VALUES ('83', '2', '1', 'name72', 'user72', '123456', 'user72@example.com', '12345678972');
INSERT INTO `person` VALUES ('84', '2', '1', 'name73', 'user73', '123456', 'user73@example.com', '12345678973');
INSERT INTO `person` VALUES ('85', '2', '1', 'name74', 'user74', '123456', 'user74@example.com', '12345678974');
INSERT INTO `person` VALUES ('86', '1', '1', 'name75', 'user75', '123456', 'user75@example.com', '12345678975');
INSERT INTO `person` VALUES ('87', '1', '1', 'name76', 'user76', '123456', 'user76@example.com', '12345678976');
INSERT INTO `person` VALUES ('88', '1', '1', 'name77', 'user77', '123456', 'user77@example.com', '12345678977');
INSERT INTO `person` VALUES ('89', '1', '1', 'name78', 'user78', '123456', 'user78@example.com', '12345678978');
INSERT INTO `person` VALUES ('90', '1', '1', 'name79', 'user79', '123456', 'user79@example.com', '12345678979');
INSERT INTO `person` VALUES ('91', '1', '1', 'name80', 'user80', '123456', 'user80@example.com', '12345678980');
INSERT INTO `person` VALUES ('92', '1', '1', 'name81', 'user81', '123456', 'user81@example.com', '12345678981');
INSERT INTO `person` VALUES ('93', '1', '1', 'name82', 'user82', '123456', 'user82@example.com', '12345678982');
INSERT INTO `person` VALUES ('94', '1', '1', 'name83', 'user83', '123456', 'user83@example.com', '12345678983');
INSERT INTO `person` VALUES ('95', '1', '1', 'name84', 'user84', '123456', 'user84@example.com', '12345678984');
INSERT INTO `person` VALUES ('96', '1', '1', 'name85', 'user85', '123456', 'user85@example.com', '12345678985');
INSERT INTO `person` VALUES ('97', '1', '1', 'name86', 'user86', '123456', 'user86@example.com', '12345678986');
INSERT INTO `person` VALUES ('98', '1', '1', 'name87', 'user87', '123456', 'user87@example.com', '12345678987');
INSERT INTO `person` VALUES ('99', '1', '1', 'name88', 'user88', '123456', 'user88@example.com', '12345678988');
INSERT INTO `person` VALUES ('100', '1', '1', 'name89', 'user89', '123456', 'user89@example.com', '12345678989');
INSERT INTO `person` VALUES ('101', '1', '1', 'name90', 'user90', '123456', 'user90@example.com', '12345678990');
INSERT INTO `person` VALUES ('102', '1', '1', 'name91', 'user91', '123456', 'user91@example.com', '12345678991');
INSERT INTO `person` VALUES ('103', '1', '1', 'name92', 'user92', '123456', 'user92@example.com', '12345678992');
INSERT INTO `person` VALUES ('104', '1', '1', 'name93', 'user93', '123456', 'user93@example.com', '12345678993');
INSERT INTO `person` VALUES ('105', '1', '1', 'name94', 'user94', '123456', 'user94@example.com', '12345678994');
INSERT INTO `person` VALUES ('106', '1', '1', 'name95', 'user95', '123456', 'user95@example.com', '12345678995');
INSERT INTO `person` VALUES ('107', '1', '1', 'name96', 'user96', '123456', 'user96@example.com', '12345678996');
INSERT INTO `person` VALUES ('108', '1', '1', 'name97', 'user97', '123456', 'user97@example.com', '12345678997');
INSERT INTO `person` VALUES ('109', '1', '1', 'name98', 'user98', '123456', 'user98@example.com', '12345678998');
INSERT INTO `person` VALUES ('110', '1', '1', 'name99', 'user99', '123456', 'user99@example.com', '12345678999');
INSERT INTO `person` VALUES ('111', '1', '1', 'name100', 'user100', '123456', 'user100@example.com', '12345678100');
INSERT INTO `person` VALUES ('112', '1', '1', 'name101', 'user101', '123456', 'user101@example.com', '12345678101');
INSERT INTO `person` VALUES ('113', '1', '1', 'name102', 'user102', '123456', 'user102@example.com', '12345678102');
INSERT INTO `person` VALUES ('114', '1', '1', 'name103', 'user103', '123456', 'user103@example.com', '12345678103');
INSERT INTO `person` VALUES ('115', '1', '1', 'name104', 'user104', '123456', 'user104@example.com', '12345678104');
INSERT INTO `person` VALUES ('116', '1', '1', 'name105', 'user105', '123456', 'user105@example.com', '12345678105');
INSERT INTO `person` VALUES ('117', '1', '1', 'name106', 'user106', '123456', 'user106@example.com', '12345678106');
INSERT INTO `person` VALUES ('118', '1', '1', 'name107', 'user107', '123456', 'user107@example.com', '12345678107');
INSERT INTO `person` VALUES ('119', '1', '1', 'name108', 'user108', '123456', 'user108@example.com', '12345678108');
INSERT INTO `person` VALUES ('120', '1', '1', 'name109', 'user109', '123456', 'user109@example.com', '12345678109');
INSERT INTO `person` VALUES ('121', '1', '1', 'name110', 'user110', '123456', 'user110@example.com', '12345678110');
INSERT INTO `person` VALUES ('122', '1', '1', 'name111', 'user111', '123456', 'user111@example.com', '12345678111');
INSERT INTO `person` VALUES ('123', '1', '1', 'name112', 'user112', '123456', 'user112@example.com', '12345678112');
INSERT INTO `person` VALUES ('124', '1', '1', 'name113', 'user113', '123456', 'user113@example.com', '12345678113');
INSERT INTO `person` VALUES ('125', '1', '1', 'name114', 'user114', '123456', 'user114@example.com', '12345678114');
INSERT INTO `person` VALUES ('126', '1', '1', 'name115', 'user115', '123456', 'user115@example.com', '12345678115');
INSERT INTO `person` VALUES ('127', '1', '1', 'name116', 'user116', '123456', 'user116@example.com', '12345678116');
INSERT INTO `person` VALUES ('128', '1', '1', 'name117', 'user117', '123456', 'user117@example.com', '12345678117');
INSERT INTO `person` VALUES ('129', '1', '1', 'name118', 'user118', '123456', 'user118@example.com', '12345678118');
INSERT INTO `person` VALUES ('130', '1', '1', 'name119', 'user119', '123456', 'user119@example.com', '12345678119');
INSERT INTO `person` VALUES ('131', '1', '1', 'name120', 'user120', '123456', 'user120@example.com', '12345678120');
INSERT INTO `person` VALUES ('132', '1', '1', 'name121', 'user121', '123456', 'user121@example.com', '12345678121');
INSERT INTO `person` VALUES ('133', '1', '1', 'name122', 'user122', '123456', 'user122@example.com', '12345678122');
INSERT INTO `person` VALUES ('134', '1', '1', 'name123', 'user123', '123456', 'user123@example.com', '12345678123');
INSERT INTO `person` VALUES ('135', '1', '1', 'name124', 'user124', '123456', 'user124@example.com', '12345678124');
INSERT INTO `person` VALUES ('136', '1', '1', 'name125', 'user125', '123456', 'user125@example.com', '12345678125');
INSERT INTO `person` VALUES ('137', '1', '1', 'name126', 'user126', '123456', 'user126@example.com', '12345678126');
INSERT INTO `person` VALUES ('138', '1', '1', 'name127', 'user127', '123456', 'user127@example.com', '12345678127');
INSERT INTO `person` VALUES ('139', '1', '1', 'name128', 'user128', '123456', 'user128@example.com', '12345678128');
INSERT INTO `person` VALUES ('140', '1', '1', 'name129', 'user129', '123456', 'user129@example.com', '12345678129');
INSERT INTO `person` VALUES ('141', '1', '1', 'name130', 'user130', '123456', 'user130@example.com', '12345678130');
INSERT INTO `person` VALUES ('142', '1', '1', 'name131', 'user131', '123456', 'user131@example.com', '12345678131');
INSERT INTO `person` VALUES ('143', '1', '1', 'name132', 'user132', '123456', 'user132@example.com', '12345678132');
INSERT INTO `person` VALUES ('144', '1', '1', 'name133', 'user133', '123456', 'user133@example.com', '12345678133');
INSERT INTO `person` VALUES ('145', '1', '1', 'name134', 'user134', '123456', 'user134@example.com', '12345678134');
INSERT INTO `person` VALUES ('146', '1', '1', 'name135', 'user135', '123456', 'user135@example.com', '12345678135');
INSERT INTO `person` VALUES ('147', '1', '1', 'name136', 'user136', '123456', 'user136@example.com', '12345678136');
INSERT INTO `person` VALUES ('148', '1', '1', 'name137', 'user137', '123456', 'user137@example.com', '12345678137');
INSERT INTO `person` VALUES ('149', '1', '1', 'name138', 'user138', '123456', 'user138@example.com', '12345678138');
INSERT INTO `person` VALUES ('150', '1', '1', 'name139', 'user139', '123456', 'user139@example.com', '12345678139');
INSERT INTO `person` VALUES ('151', '1', '1', 'name140', 'user140', '123456', 'user140@example.com', '12345678140');
INSERT INTO `person` VALUES ('152', '1', '1', 'name141', 'user141', '123456', 'user141@example.com', '12345678141');
INSERT INTO `person` VALUES ('153', '1', '1', 'name142', 'user142', '123456', 'user142@example.com', '12345678142');
INSERT INTO `person` VALUES ('154', '1', '1', 'name143', 'user143', '123456', 'user143@example.com', '12345678143');
INSERT INTO `person` VALUES ('155', '1', '1', 'name144', 'user144', '123456', 'user144@example.com', '12345678144');
INSERT INTO `person` VALUES ('156', '1', '1', 'name145', 'user145', '123456', 'user145@example.com', '12345678145');
INSERT INTO `person` VALUES ('157', '1', '1', 'name146', 'user146', '123456', 'user146@example.com', '12345678146');
INSERT INTO `person` VALUES ('158', '1', '1', 'name147', 'user147', '123456', 'user147@example.com', '12345678147');
INSERT INTO `person` VALUES ('159', '1', '1', 'name148', 'user148', '123456', 'user148@example.com', '12345678148');
INSERT INTO `person` VALUES ('160', '1', '1', 'name149', 'user149', '123456', 'user149@example.com', '12345678149');
INSERT INTO `person` VALUES ('161', '1', '1', 'name150', 'user150', '123456', 'user150@example.com', '12345678150');
INSERT INTO `person` VALUES ('162', '1', '1', 'name151', 'user151', '123456', 'user151@example.com', '12345678151');
INSERT INTO `person` VALUES ('163', '1', '1', 'name152', 'user152', '123456', 'user152@example.com', '12345678152');
INSERT INTO `person` VALUES ('164', '1', '1', 'name153', 'user153', '123456', 'user153@example.com', '12345678153');
INSERT INTO `person` VALUES ('165', '1', '1', 'name154', 'user154', '123456', 'user154@example.com', '12345678154');
INSERT INTO `person` VALUES ('166', '1', '1', 'name155', 'user155', '123456', 'user155@example.com', '12345678155');
INSERT INTO `person` VALUES ('167', '1', '1', 'name156', 'user156', '123456', 'user156@example.com', '12345678156');
INSERT INTO `person` VALUES ('168', '1', '1', 'name157', 'user157', '123456', 'user157@example.com', '12345678157');
INSERT INTO `person` VALUES ('169', '1', '1', 'name158', 'user158', '123456', 'user158@example.com', '12345678158');
INSERT INTO `person` VALUES ('170', '1', '1', 'name159', 'user159', '123456', 'user159@example.com', '12345678159');
INSERT INTO `person` VALUES ('171', '1', '1', 'name160', 'user160', '123456', 'user160@example.com', '12345678160');

-- ----------------------------
-- Table structure for team
-- ----------------------------
DROP TABLE IF EXISTS `team`;
CREATE TABLE `team` (
  `team_id` int(11) NOT NULL AUTO_INCREMENT,
  `leader_person_id` int(11) DEFAULT NULL,
  `member_info` text,
  `entry_id` int(11) DEFAULT NULL,
  `comp_id` int(11) DEFAULT NULL,
  `cotle_id` int(11) DEFAULT NULL,
  `team` int(11) DEFAULT NULL,
  `team_end` int(11) DEFAULT NULL,
  `team_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`team_id`)
) ENGINE=InnoDB AUTO_INCREMENT=53 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of team
-- ----------------------------
INSERT INTO `team` VALUES ('1', '12', 'member_info1', '1', '20', '20', '3', '2', '生存创业冠军队');
INSERT INTO `team` VALUES ('2', '13', 'member_info2', '2', '20', '20', '3', '2', '海洋环保冠军队');
INSERT INTO `team` VALUES ('3', '14', 'member_info3', '3', '20', '20', '3', '2', '创新科技先锋队');
INSERT INTO `team` VALUES ('4', '15', 'member_info4', '4', '20', '20', '3', '2', '智慧发展冲锋队');
INSERT INTO `team` VALUES ('5', '16', 'member_info5', '5', '20', '20', '3', '2', '激情拼搏卓越队');
INSERT INTO `team` VALUES ('6', '17', 'member_info6', '6', '20', '20', '3', '2', '多元融合奋进队');
INSERT INTO `team` VALUES ('7', '18', 'member_info7', '7', '20', '20', '3', '2', '绿色发展精英队');
INSERT INTO `team` VALUES ('8', '19', 'member_info8', '8', '20', '20', '3', '2', '科技引领荣耀队');
INSERT INTO `team` VALUES ('9', '20', 'member_info9', '9', '20', '20', '3', '2', '稳健前行无畏队');
INSERT INTO `team` VALUES ('10', '21', 'member_info10', '10', '20', '20', '3', '2', '精准定位勇士队');
INSERT INTO `team` VALUES ('11', '22', 'member_info11', '11', '20', '20', '3', '2', '特色创新王牌队');
INSERT INTO `team` VALUES ('12', '23', 'member_info12', '12', '20', '20', '3', '2', '高效行动先锋队');
INSERT INTO `team` VALUES ('13', '24', 'member_info13', '13', '20', '20', '3', '2', '融合创新卓越队');
INSERT INTO `team` VALUES ('14', '25', 'member_info14', '14', '20', '20', '3', '2', '专业专注明星队');
INSERT INTO `team` VALUES ('15', '26', 'member_info15', '15', '20', '20', '3', '2', '梦想追逐飞翔队');
INSERT INTO `team` VALUES ('16', '27', 'member_info16', '16', '20', '20', '3', '2', '先锋探索勇者队');
INSERT INTO `team` VALUES ('17', '28', 'member_info17', '17', '20', '20', '3', '2', '魅力展现风采队');
INSERT INTO `team` VALUES ('18', '29', 'member_info18', '18', '20', '20', '3', '2', '开拓进取辉煌队');
INSERT INTO `team` VALUES ('19', '30', 'member_info19', '19', '20', '20', '3', '2', '进取突破超越队');
INSERT INTO `team` VALUES ('20', '31', 'member_info20', '20', '20', '20', '3', '2', '活力无限闪耀队');
INSERT INTO `team` VALUES ('21', '32', 'member_info21', '21', '20', '20', '3', '2', '创新驱动飞跃队');
INSERT INTO `team` VALUES ('22', '33', 'member_info22', '22', '20', '20', '3', '2', '智慧引领卓越队');
INSERT INTO `team` VALUES ('23', '34', 'member_info23', '23', '20', '20', '3', '2', '激情燃烧勇者队');
INSERT INTO `team` VALUES ('24', '35', 'member_info24', '24', '20', '20', '3', '2', '多元绽放明星队');
INSERT INTO `team` VALUES ('25', '36', 'member_info25', '25', '20', '20', '3', '2', '绿色先行冲锋队');
INSERT INTO `team` VALUES ('26', '37', 'member_info26', '26', '20', '20', '3', '2', '科技领航荣耀队');
INSERT INTO `team` VALUES ('27', '38', 'member_info27', '27', '20', '20', '3', '2', '稳健迈进精英队');
INSERT INTO `team` VALUES ('28', '39', 'member_info28', '28', '20', '20', '3', '2', '精准出击王牌队');
INSERT INTO `team` VALUES ('29', '40', 'member_info29', '29', '20', '20', '3', '2', '特色绽放风采队');
INSERT INTO `team` VALUES ('30', '41', 'member_info30', '30', '20', '20', '3', '2', '高效奋进勇士队');
INSERT INTO `team` VALUES ('31', '12', '团队经验十分丰富', '31', '22', '22', '1', '1', '正能量队');
INSERT INTO `team` VALUES ('32', '13', '团队经验十分丰富', '32', '22', '22', '1', '1', '正能量队2');
INSERT INTO `team` VALUES ('33', '14', '团队经验十分丰富', '33', '22', '22', '1', '1', '正能量队3');
INSERT INTO `team` VALUES ('34', '15', '团队经验十分丰富', '34', '22', '22', '1', '1', '正能量队4');
INSERT INTO `team` VALUES ('35', '16', '团队经验十分丰富', '35', '22', '23', '1', '1', '正能量队5');
INSERT INTO `team` VALUES ('36', '17', '团队经验十分丰富', '36', '22', '23', '1', '1', '正能量队6');
INSERT INTO `team` VALUES ('37', '18', '团队经验十分丰富', '37', '22', '22', '1', '1', '正能量队7');
INSERT INTO `team` VALUES ('38', '19', '团队经验十分丰富', '38', '22', '22', '1', '1', '正能量队8');
INSERT INTO `team` VALUES ('39', '20', '团队经验十分丰富', '40', '22', '22', '1', '1', '正能量队9');
INSERT INTO `team` VALUES ('40', '21', '团队经验十分丰富', '39', '22', '22', '1', '1', '正能量队10');
INSERT INTO `team` VALUES ('41', '51', '团队经验非常丰富', '41', '23', '24', '1', '1', '正能量队11');
INSERT INTO `team` VALUES ('42', '52', '团队经验非常丰富', '42', '23', '24', '1', '1', '正能量队12');
INSERT INTO `team` VALUES ('43', '53', '团队经验非常丰富', '43', '23', '24', '1', '1', '正能量队13');
INSERT INTO `team` VALUES ('44', '54', '团队经验非常丰富', '44', '24', '25', '1', '1', '正能量队14');
INSERT INTO `team` VALUES ('45', '55', '团队经验非常丰富', '45', '24', '25', '1', '1', '正能量队156');
INSERT INTO `team` VALUES ('46', '56', '团队经验非常丰富', '46', '23', '24', '1', '1', '正能量队16');
INSERT INTO `team` VALUES ('47', '57', '团队经验非常丰富', '47', '25', '26', '1', '1', '正能量队17');
INSERT INTO `team` VALUES ('48', '58', '团队经验非常丰富', '48', '25', '26', '1', '1', '正能量队18');
INSERT INTO `team` VALUES ('49', '59', '团队经验非常丰富', '49', '25', '26', '1', '1', '正能量队19');
INSERT INTO `team` VALUES ('50', '60', '团队经验非常丰富', '50', '26', '27', '1', '1', '正能量队20');
INSERT INTO `team` VALUES ('51', '61', '团队经验非常丰富', '51', '26', '27', '1', '1', '正能量队21');
INSERT INTO `team` VALUES ('52', '62', '团队经验非常丰富', '52', '26', '27', '1', '1', '正能量队22');

-- ----------------------------
-- Table structure for team_leader
-- ----------------------------
DROP TABLE IF EXISTS `team_leader`;
CREATE TABLE `team_leader` (
  `leader_id` int(11) NOT NULL AUTO_INCREMENT,
  `team_id` int(11) DEFAULT NULL,
  `person_id` int(11) DEFAULT NULL,
  `team_end` int(11) DEFAULT NULL,
  PRIMARY KEY (`leader_id`)
) ENGINE=InnoDB AUTO_INCREMENT=53 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of team_leader
-- ----------------------------
INSERT INTO `team_leader` VALUES ('1', '1', '12', '2');
INSERT INTO `team_leader` VALUES ('2', '2', '13', '2');
INSERT INTO `team_leader` VALUES ('3', '3', '14', '2');
INSERT INTO `team_leader` VALUES ('4', '4', '15', '2');
INSERT INTO `team_leader` VALUES ('5', '5', '16', '2');
INSERT INTO `team_leader` VALUES ('6', '6', '17', '2');
INSERT INTO `team_leader` VALUES ('7', '7', '18', '2');
INSERT INTO `team_leader` VALUES ('8', '8', '19', '2');
INSERT INTO `team_leader` VALUES ('9', '9', '20', '2');
INSERT INTO `team_leader` VALUES ('10', '10', '21', '2');
INSERT INTO `team_leader` VALUES ('11', '11', '22', '2');
INSERT INTO `team_leader` VALUES ('12', '12', '23', '2');
INSERT INTO `team_leader` VALUES ('13', '13', '24', '2');
INSERT INTO `team_leader` VALUES ('14', '14', '25', '2');
INSERT INTO `team_leader` VALUES ('15', '15', '26', '2');
INSERT INTO `team_leader` VALUES ('16', '16', '27', '2');
INSERT INTO `team_leader` VALUES ('17', '17', '28', '2');
INSERT INTO `team_leader` VALUES ('18', '18', '29', '2');
INSERT INTO `team_leader` VALUES ('19', '19', '30', '2');
INSERT INTO `team_leader` VALUES ('20', '20', '31', '2');
INSERT INTO `team_leader` VALUES ('21', '21', '32', '2');
INSERT INTO `team_leader` VALUES ('22', '22', '33', '2');
INSERT INTO `team_leader` VALUES ('23', '23', '34', '2');
INSERT INTO `team_leader` VALUES ('24', '24', '35', '2');
INSERT INTO `team_leader` VALUES ('25', '25', '36', '2');
INSERT INTO `team_leader` VALUES ('26', '26', '37', '2');
INSERT INTO `team_leader` VALUES ('27', '27', '38', '2');
INSERT INTO `team_leader` VALUES ('28', '28', '39', '2');
INSERT INTO `team_leader` VALUES ('29', '29', '40', '2');
INSERT INTO `team_leader` VALUES ('30', '30', '41', '2');
INSERT INTO `team_leader` VALUES ('31', '31', '12', '1');
INSERT INTO `team_leader` VALUES ('32', '32', '13', '1');
INSERT INTO `team_leader` VALUES ('33', '33', '14', '1');
INSERT INTO `team_leader` VALUES ('34', '34', '15', '1');
INSERT INTO `team_leader` VALUES ('35', '35', '16', '1');
INSERT INTO `team_leader` VALUES ('36', '36', '17', '1');
INSERT INTO `team_leader` VALUES ('37', '37', '18', '1');
INSERT INTO `team_leader` VALUES ('38', '38', '19', '1');
INSERT INTO `team_leader` VALUES ('39', '39', '20', '1');
INSERT INTO `team_leader` VALUES ('40', '40', '21', '1');
INSERT INTO `team_leader` VALUES ('41', '41', '51', '1');
INSERT INTO `team_leader` VALUES ('42', '42', '52', '1');
INSERT INTO `team_leader` VALUES ('43', '43', '53', '1');
INSERT INTO `team_leader` VALUES ('44', '44', '54', '1');
INSERT INTO `team_leader` VALUES ('45', '45', '55', '1');
INSERT INTO `team_leader` VALUES ('46', '46', '56', '1');
INSERT INTO `team_leader` VALUES ('47', '47', '57', '1');
INSERT INTO `team_leader` VALUES ('48', '48', '58', '1');
INSERT INTO `team_leader` VALUES ('49', '49', '59', '1');
INSERT INTO `team_leader` VALUES ('50', '50', '60', '1');
INSERT INTO `team_leader` VALUES ('51', '51', '61', '1');
INSERT INTO `team_leader` VALUES ('52', '52', '62', '1');

-- ----------------------------
-- Table structure for team_member
-- ----------------------------
DROP TABLE IF EXISTS `team_member`;
CREATE TABLE `team_member` (
  `member_id` int(11) NOT NULL AUTO_INCREMENT,
  `team_id` int(11) DEFAULT NULL,
  `person_id` int(11) DEFAULT NULL,
  `team_end` int(11) DEFAULT NULL,
  PRIMARY KEY (`member_id`)
) ENGINE=InnoDB AUTO_INCREMENT=105 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of team_member
-- ----------------------------
INSERT INTO `team_member` VALUES ('1', '1', '42', '2');
INSERT INTO `team_member` VALUES ('2', '1', '43', '2');
INSERT INTO `team_member` VALUES ('3', '2', '44', '2');
INSERT INTO `team_member` VALUES ('4', '2', '45', '2');
INSERT INTO `team_member` VALUES ('5', '3', '46', '2');
INSERT INTO `team_member` VALUES ('6', '3', '47', '2');
INSERT INTO `team_member` VALUES ('7', '4', '48', '2');
INSERT INTO `team_member` VALUES ('8', '4', '49', '2');
INSERT INTO `team_member` VALUES ('9', '5', '50', '2');
INSERT INTO `team_member` VALUES ('10', '5', '51', '2');
INSERT INTO `team_member` VALUES ('11', '6', '52', '2');
INSERT INTO `team_member` VALUES ('12', '6', '53', '2');
INSERT INTO `team_member` VALUES ('13', '7', '54', '2');
INSERT INTO `team_member` VALUES ('14', '7', '55', '2');
INSERT INTO `team_member` VALUES ('15', '8', '56', '2');
INSERT INTO `team_member` VALUES ('16', '8', '57', '2');
INSERT INTO `team_member` VALUES ('17', '9', '58', '2');
INSERT INTO `team_member` VALUES ('18', '9', '59', '2');
INSERT INTO `team_member` VALUES ('19', '10', '60', '2');
INSERT INTO `team_member` VALUES ('20', '10', '61', '2');
INSERT INTO `team_member` VALUES ('21', '11', '62', '2');
INSERT INTO `team_member` VALUES ('22', '11', '63', '2');
INSERT INTO `team_member` VALUES ('23', '12', '64', '2');
INSERT INTO `team_member` VALUES ('24', '12', '65', '2');
INSERT INTO `team_member` VALUES ('25', '13', '66', '2');
INSERT INTO `team_member` VALUES ('26', '13', '67', '2');
INSERT INTO `team_member` VALUES ('27', '14', '68', '2');
INSERT INTO `team_member` VALUES ('28', '14', '69', '2');
INSERT INTO `team_member` VALUES ('29', '15', '70', '2');
INSERT INTO `team_member` VALUES ('30', '15', '71', '2');
INSERT INTO `team_member` VALUES ('31', '16', '72', '2');
INSERT INTO `team_member` VALUES ('32', '16', '73', '2');
INSERT INTO `team_member` VALUES ('33', '17', '74', '2');
INSERT INTO `team_member` VALUES ('34', '17', '75', '2');
INSERT INTO `team_member` VALUES ('35', '18', '76', '2');
INSERT INTO `team_member` VALUES ('36', '18', '77', '2');
INSERT INTO `team_member` VALUES ('37', '19', '78', '2');
INSERT INTO `team_member` VALUES ('38', '19', '79', '2');
INSERT INTO `team_member` VALUES ('39', '20', '80', '2');
INSERT INTO `team_member` VALUES ('40', '20', '81', '2');
INSERT INTO `team_member` VALUES ('41', '21', '82', '2');
INSERT INTO `team_member` VALUES ('42', '21', '83', '2');
INSERT INTO `team_member` VALUES ('43', '22', '84', '2');
INSERT INTO `team_member` VALUES ('44', '22', '85', '2');
INSERT INTO `team_member` VALUES ('45', '23', '86', '2');
INSERT INTO `team_member` VALUES ('46', '23', '87', '2');
INSERT INTO `team_member` VALUES ('47', '24', '88', '2');
INSERT INTO `team_member` VALUES ('48', '24', '89', '2');
INSERT INTO `team_member` VALUES ('49', '25', '90', '2');
INSERT INTO `team_member` VALUES ('50', '25', '91', '2');
INSERT INTO `team_member` VALUES ('51', '26', '92', '2');
INSERT INTO `team_member` VALUES ('52', '26', '93', '2');
INSERT INTO `team_member` VALUES ('53', '27', '94', '2');
INSERT INTO `team_member` VALUES ('54', '27', '95', '2');
INSERT INTO `team_member` VALUES ('55', '28', '96', '2');
INSERT INTO `team_member` VALUES ('56', '28', '97', '2');
INSERT INTO `team_member` VALUES ('57', '29', '98', '2');
INSERT INTO `team_member` VALUES ('58', '29', '99', '2');
INSERT INTO `team_member` VALUES ('59', '30', '100', '2');
INSERT INTO `team_member` VALUES ('60', '30', '101', '2');
INSERT INTO `team_member` VALUES ('61', '31', '22', '1');
INSERT INTO `team_member` VALUES ('62', '31', '23', '1');
INSERT INTO `team_member` VALUES ('63', '32', '24', '1');
INSERT INTO `team_member` VALUES ('64', '32', '25', '1');
INSERT INTO `team_member` VALUES ('65', '33', '26', '1');
INSERT INTO `team_member` VALUES ('66', '33', '27', '1');
INSERT INTO `team_member` VALUES ('67', '34', '28', '1');
INSERT INTO `team_member` VALUES ('68', '34', '29', '1');
INSERT INTO `team_member` VALUES ('69', '35', '30', '1');
INSERT INTO `team_member` VALUES ('70', '35', '31', '1');
INSERT INTO `team_member` VALUES ('71', '36', '32', '1');
INSERT INTO `team_member` VALUES ('72', '36', '33', '1');
INSERT INTO `team_member` VALUES ('73', '37', '34', '1');
INSERT INTO `team_member` VALUES ('74', '37', '35', '1');
INSERT INTO `team_member` VALUES ('75', '38', '36', '1');
INSERT INTO `team_member` VALUES ('76', '38', '37', '1');
INSERT INTO `team_member` VALUES ('77', '39', '39', '1');
INSERT INTO `team_member` VALUES ('78', '39', '40', '1');
INSERT INTO `team_member` VALUES ('79', '40', '41', '1');
INSERT INTO `team_member` VALUES ('80', '40', '42', '1');
INSERT INTO `team_member` VALUES ('81', '41', '38', '1');
INSERT INTO `team_member` VALUES ('82', '41', '43', '1');
INSERT INTO `team_member` VALUES ('83', '42', '44', '1');
INSERT INTO `team_member` VALUES ('84', '42', '45', '1');
INSERT INTO `team_member` VALUES ('85', '43', '46', '1');
INSERT INTO `team_member` VALUES ('86', '43', '47', '1');
INSERT INTO `team_member` VALUES ('87', '44', '48', '1');
INSERT INTO `team_member` VALUES ('88', '44', '49', '1');
INSERT INTO `team_member` VALUES ('89', '45', '50', '1');
INSERT INTO `team_member` VALUES ('90', '45', '71', '1');
INSERT INTO `team_member` VALUES ('91', '46', '72', '1');
INSERT INTO `team_member` VALUES ('92', '46', '73', '1');
INSERT INTO `team_member` VALUES ('93', '47', '74', '1');
INSERT INTO `team_member` VALUES ('94', '47', '75', '1');
INSERT INTO `team_member` VALUES ('95', '48', '76', '1');
INSERT INTO `team_member` VALUES ('96', '48', '77', '1');
INSERT INTO `team_member` VALUES ('97', '49', '78', '1');
INSERT INTO `team_member` VALUES ('98', '49', '79', '1');
INSERT INTO `team_member` VALUES ('99', '50', '80', '1');
INSERT INTO `team_member` VALUES ('100', '50', '81', '1');
INSERT INTO `team_member` VALUES ('101', '51', '82', '1');
INSERT INTO `team_member` VALUES ('102', '51', '83', '1');
INSERT INTO `team_member` VALUES ('103', '52', '84', '1');
INSERT INTO `team_member` VALUES ('104', '52', '85', '1');
